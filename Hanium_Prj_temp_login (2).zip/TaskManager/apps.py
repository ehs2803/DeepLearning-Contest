from django.apps import AppConfig


class TaskManagerConfig(AppConfig):
    name = 'TaskManager'
